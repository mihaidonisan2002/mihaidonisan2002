package com.example.javafxproject.model;

import java.time.LocalDateTime;

public class Spectacle extends Entity<Long> {

    private String name;
    private LocalDateTime datetime;
    private String categorie;
    private int availableSeats;

    public Spectacle(String name, LocalDateTime datetime, String categorie, int availableSeats) {
        this.name = name;
        this.datetime = datetime;
        this.categorie = categorie;
        this.availableSeats = availableSeats;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getDateTime() {
        return datetime;
    }

    public void setDateTime(LocalDateTime DateTime) {
        this.datetime = DateTime;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    @Override
    public String toString() {
        return "Spectacle{" +
                "name='" + name + '\'' +
                ", DateTime=" + datetime +
                ", categorie='" + categorie + '\'' +
                ", availableSeats=" + availableSeats +
                '}';
    }
}
