package com.example.javafxproject.gui;

import com.example.javafxproject.model.Spectacle;
import com.example.javafxproject.model.dto.SpectacleDto;
import com.example.javafxproject.service.Service;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

public class MainViewController {
    ObservableList<SpectacleDto> model = FXCollections.observableArrayList();

    public TextField nameTextEdit;
    public TextField addressTextEdit;
    public TextField spectatorsTextEdit;

    public TextField namesTextEdit;
    public Button searchButton;
    public TableColumn<SpectacleDto, String> nameColumn;
    public TableColumn<SpectacleDto, String> dattimeColumn;
    public TableColumn<SpectacleDto, String> categorieColumn;
    public TableColumn<SpectacleDto, String> avbSeatsColumn;
    public Button bookButton;
    public DatePicker dDatePicker;
    public TableView<SpectacleDto> spectaclesTable;


    private Service service;

    public void setService(Service service) {
        this.service = service;
        initializeFields();
        populateTable();
    }

    private void populateTable() {
        List<Spectacle> spectacles = (List<Spectacle>) service.getAllSpectacles();
        model.setAll(spectacles.stream().map(flight -> new SpectacleDto(flight, service)).toList());
    }

    private void initializeFields() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        dattimeColumn.setCellValueFactory(new PropertyValueFactory<>("dattime"));
        categorieColumn.setCellValueFactory(new PropertyValueFactory<>("categorie"));
        avbSeatsColumn.setCellValueFactory(new PropertyValueFactory<>("avbSeats"));
        spectaclesTable.setItems(model);
    }

    public void searchClicked() {
        LocalDateTime localDateTime = dDatePicker.getValue().atStartOfDay();
        String name = namesTextEdit.getText();

        List<Spectacle> spectacles = (List<Spectacle>) service.getSpectaclesForNameAndDate(name, localDateTime);
        model.setAll(spectacles.stream().map(flight -> new SpectacleDto(flight, service)).toList());
    }

    public void bookClicked() throws IOException {
        SpectacleDto selectedSpectacle = spectaclesTable.getSelectionModel().getSelectedItem();
        if (selectedSpectacle == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No spectacle selected");
            alert.setContentText("Please select a spectacle to book");
            alert.showAndWait();
            return;
        }
        selectedSpectacle.setAvbSeats("80");
        String name = nameTextEdit.getText();
        String address = addressTextEdit.getText();
        String spectatorsString = spectatorsTextEdit.getText();
        List<String> spectators = List.of(spectatorsString.split(","));

        if (name.isEmpty() || address.isEmpty() || spectatorsString.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Empty fields");
            alert.setContentText("Please fill in all fields");
            alert.showAndWait();
            return;
        }

        boolean succeeded = service.bookSpectacle(selectedSpectacle.getId(), name, address, spectators);
        if (!succeeded) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText("Booking successful");
            alert.setContentText("Booking successful");
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Booking failed");
        alert.setContentText("Booking failed");
        alert.showAndWait();
    }

    public void clearButtonClicked() {
        namesTextEdit.setText("");
        dDatePicker.setValue(null);
        populateTable();
    }
}
