package com.example.javafxproject;

import com.example.javafxproject.gui.LoginController;
import com.example.javafxproject.repository.AgencyRepository;
import com.example.javafxproject.service.Service;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Properties properties = new Properties();
        try {
            properties.load(new FileReader("C:\\Users\\mihai\\source\\JavaFxProject\\bd.properties"));

        } catch (Exception e) {
            e.printStackTrace();
        }

        Service service = new Service(properties);

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("login.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        LoginController loginController = fxmlLoader.getController();
        loginController.setService(service);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {
        launch();
    }
}