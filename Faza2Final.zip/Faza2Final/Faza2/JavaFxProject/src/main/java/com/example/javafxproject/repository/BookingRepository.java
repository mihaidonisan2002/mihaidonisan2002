package com.example.javafxproject.repository;

import com.example.javafxproject.model.Booking;
import com.example.javafxproject.model.Client;
import com.example.javafxproject.model.Spectacle;
import com.example.javafxproject.utils.JdbcUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;

public class BookingRepository implements IBookingRepository {

    private final JdbcUtils jdbcUtils;
    private static final Logger logger = LogManager.getLogger();

    public BookingRepository(Properties properties) {
        logger.info("Initialised Booking repository with properties: {}", properties);
        jdbcUtils = new JdbcUtils(properties);
    }

    @Override
    public Booking findOne(Long aLong) {
        logger.traceEntry();
        Booking booking = null;

        String sql = "SELECT * FROM bookings b " +
                "INNER JOIN spectacles f on f.id = b.id_flight " +
                "INNER JOIN clients c on c.id = b.id_client WHERE b.id = ?";

        try (
                Connection connection = jdbcUtils.getConnection()
        ) {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setLong(1, aLong);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                Long id = resultSet.getLong("id");
                System.out.println(id);
                Long idClient = resultSet.getLong("id_client");
                String clientName = resultSet.getString("client_name");
                String address = resultSet.getString("address");
                Client client = new Client(clientName, address);
                client.setId(idClient);

                Long idSpectacle = resultSet.getLong("id_spectacle");
                String name = resultSet.getString("name");
                LocalDateTime datTime = resultSet
                        .getTimestamp("date_time").toLocalDateTime();
                String categorie = resultSet.getString("categorie");
                int availableSeats = resultSet.getInt("available_seats");
                Spectacle spectacle = new Spectacle(name, datTime, categorie, availableSeats);
                spectacle.setId(idSpectacle);

                String passengersString = resultSet.getString("clients_name");

                List<String> passengers = Arrays.asList(passengersString.split(","));

                booking = new Booking(spectacle, client, passengers);
                booking.setId(id);
            }
        } catch (SQLException e) {
            logger.error(e);
            e.printStackTrace();
        }

        logger.traceExit();
        return booking;
    }

    @Override
    public Iterable<Booking> findAll() {
        logger.traceEntry();
        List<Booking> bookings = new ArrayList<>();

        String sql = "SELECT * FROM bookings b " +
                "INNER JOIN spectacles f on f.id = b.id_flight " +
                "INNER JOIN clients c on c.id = b.id_client";

        try (
                Connection connection = jdbcUtils.getConnection()
        ) {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                System.out.println(id);
                Long idClient = resultSet.getLong("id_client");
                String clientName = resultSet.getString("client_name");
                String address = resultSet.getString("address");
                Client client = new Client(clientName, address);
                client.setId(idClient);

                Long idSpectacle = resultSet.getLong("id_spectacle");
                String name = resultSet.getString("name");
                LocalDateTime datTime = resultSet
                        .getTimestamp("date_time").toLocalDateTime();
                String categorie = resultSet.getString("categorie");
                int availableSeats = resultSet.getInt("available_seats");
                Spectacle spectacle = new Spectacle(name, datTime, categorie, availableSeats);
                spectacle.setId(idSpectacle);

                String passengersString = resultSet.getString("clients_name");

                List<String> passengers = Arrays.asList(passengersString.split(","));

                Booking booking = new Booking(spectacle, client, passengers);
                booking.setId(id);

                bookings.add(booking);
            }
        } catch (SQLException e) {
            logger.error(e);
            e.printStackTrace();
        }

        logger.traceExit();
        return bookings;
    }

    public Long getLowestAvbId() {
        String sql = "SELECT MAX(id) FROM bookings";
        Long id = null;

        try (
                Connection connection = jdbcUtils.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
        ) {

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                id = resultSet.getLong(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    @Override
    public Booking save(Booking entity) {
        logger.traceEntry();
        String sql = "INSERT INTO bookings VALUES (?, ?, ?, ?)";

        try (
                Connection connection = jdbcUtils.getConnection()
        ) {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setLong(1, entity.getId());
            preparedStatement.setLong(2, entity.getSpectacle().getId());
            preparedStatement.setLong(3, entity.getClient().getId());
            String clientsList = String.join(",", entity.getSpectators());
            preparedStatement.setString(4, clientsList);

            preparedStatement.executeUpdate();
            entity = null;
        } catch (SQLException e) {
            logger.error(e);
            e.printStackTrace();
        }

        logger.traceExit();
        return entity;
    }

    @Override
    public int getNumberOfBookingsForSpectacle(Long id) {
        logger.traceEntry();
        int numberOfBookings = 0;
        String sql = "SELECT COUNT(*) FROM bookings WHERE id_spectacle = ?";

        try (
                Connection connection = jdbcUtils.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
        ) {
            preparedStatement.setLong(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                numberOfBookings = resultSet.getInt(1);
            }
        } catch (SQLException e) {
            logger.error(e);
            e.printStackTrace();
        }
        logger.traceExit();
        return numberOfBookings;
    }
}
