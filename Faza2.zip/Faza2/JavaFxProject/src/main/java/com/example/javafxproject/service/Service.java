package com.example.javafxproject.service;

import com.example.javafxproject.model.Booking;
import com.example.javafxproject.model.Client;
import com.example.javafxproject.model.Spectacle;
import com.example.javafxproject.repository.AgencyRepository;
import com.example.javafxproject.repository.BookingRepository;
import com.example.javafxproject.repository.ClientRepository;
import com.example.javafxproject.repository.SpectacleRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Properties;

public class Service {
    private AgencyRepository agencyRepository;
    private BookingRepository bookingRepository;
    private ClientRepository clientRepository;
    private SpectacleRepository SpectacleRepository;

    public Service(Properties properties) {
        agencyRepository = new AgencyRepository(properties);
        bookingRepository = new BookingRepository(properties);
        clientRepository = new ClientRepository(properties);
        SpectacleRepository = new SpectacleRepository(properties);
    }

    public boolean validateLogin(String username, String password) {
        return agencyRepository.existsUser(username, password);
    }

    public Iterable<Spectacle> getSpectaclesForNameAndDate(String Name, LocalDateTime date) {
        return SpectacleRepository.findSpectacleByNameAndDate(Name, date);
    }

    public int getNumberOfBookingsForSpectacle(Long id) {
        return bookingRepository.getNumberOfBookingsForSpectacle(id);
    }

    public Iterable<Spectacle> getAllSpectacles() {
        return SpectacleRepository.findAll();
    }

    public boolean bookSpectacle(Long SpectacleId, String clientName, String clientAddress, List<String> clients) {
        Client client = new Client(clientName, clientAddress);
        client.setId(clientRepository.getLowestAvbId() + 1);
        clientRepository.save(client);
        Booking booking = new Booking(SpectacleRepository.findOne(SpectacleId), client, clients);
        booking.setId(bookingRepository.getLowestAvbId() + 1);
        return bookingRepository.save(booking) != null;
    }
}

