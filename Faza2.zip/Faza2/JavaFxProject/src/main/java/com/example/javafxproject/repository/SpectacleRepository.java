package com.example.javafxproject.repository;

import com.example.javafxproject.model.Spectacle;
import com.example.javafxproject.utils.JdbcUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

public class SpectacleRepository implements ISpectacleRepository {

    private final JdbcUtils jdbcUtils;
    private static final Logger logger = LogManager.getLogger();

    public SpectacleRepository(Properties properties) {
        logger.info("Initialising SpectacleRepository with properties: {}", properties);
        jdbcUtils = new JdbcUtils(properties);
    }

    @Override
    public Spectacle findOne(Long aLong) {
        logger.traceEntry();
        String sql = "SELECT * FROM spectacles WHERE id = ?";
        Spectacle spectacle = null;

        try (
                Connection connection = jdbcUtils.getConnection()
        ) {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setLong(1, aLong);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                LocalDateTime datTime = resultSet
                        .getTimestamp("date_time").toLocalDateTime();
                String categorie = resultSet.getString("categorie");
                int availableSeats = resultSet.getInt("available_seats");

                spectacle = new Spectacle(name, datTime, categorie, availableSeats);
                spectacle.setId(id);
            }
        } catch (SQLException e) {
            logger.error(e);
            e.printStackTrace();
        }

        logger.traceExit();
        return spectacle;
    }

    @Override
    public Iterable<Spectacle> findAll() {
        logger.traceEntry();
        String sql = "SELECT * FROM spectacles";

        List<Spectacle> spectacles = new ArrayList<>();

        try (
                Connection connection = jdbcUtils.getConnection()
        ) {

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                LocalDateTime datTime = resultSet
                        .getTimestamp("date_time").toLocalDateTime();
                String categorie = resultSet.getString("categorie");
                if(id==1) {
                    Random rand = new Random();

                    int availableSeats = resultSet.getInt("available_seats");
                    int available=availableSeats-rand.nextInt(availableSeats);
                    Spectacle spectacle = new Spectacle(name, datTime, categorie, available);
                    spectacle.setId(id);

                    spectacles.add(spectacle);
                }
                else {
                    int availableSeats = resultSet.getInt("available_seats");
                    Spectacle spectacle = new Spectacle(name, datTime, categorie, availableSeats);
                    spectacle.setId(id);

                    spectacles.add(spectacle);
                }
            }
        } catch (SQLException e) {
            logger.error(e);
            e.printStackTrace();
        }
        logger.traceExit();
        return spectacles;
    }
    @Override
    public Spectacle save(Spectacle entity) {
        logger.traceEntry();

        String sql = "INSERT INTO spectacles VALUES (?, ?, ?, ?, ?)";

        try (
                Connection connection = jdbcUtils.getConnection()
        ) {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setLong(1, entity.getId());
            preparedStatement.setString(2, entity.getName());
            preparedStatement.setTimestamp(3, Timestamp.valueOf(entity.getDateTime()));
            preparedStatement.setString(4, entity.getCategorie());
            preparedStatement.setInt(5, entity.getAvailableSeats());

            preparedStatement.executeUpdate();
            entity = null;
        } catch (SQLException e) {
            logger.error(e);
            e.printStackTrace();
        }
        logger.traceExit();
        return entity;
    }

    @Override
    public Iterable<Spectacle> findSpectacleByNameAndDate(String Name, LocalDateTime dateTime) {
        logger.traceEntry("findSpectacleByNameAndDate: Name = {}, dateTime = {}", Name, dateTime);
        LocalDateTime start = LocalDateTime.of(dateTime.getYear(), dateTime.getMonth(), dateTime.getDayOfMonth(), 0, 0);
        LocalDateTime end = LocalDateTime.of(dateTime.getYear(), dateTime.getMonth(), dateTime.getDayOfMonth(), 23, 59);
        String sql = "SELECT * FROM spectacles WHERE Name = ? AND date_time BETWEEN ? AND ?";

        try (
                Connection connection = jdbcUtils.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
        ) {
            preparedStatement.setString(1, Name);
            preparedStatement.setTimestamp(2, Timestamp.valueOf(start));
            preparedStatement.setTimestamp(3, Timestamp.valueOf(end));

            ResultSet resultSet = preparedStatement.executeQuery();

            List<Spectacle> spectacles = new ArrayList<>();

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String Name1 = resultSet.getString("name");
                LocalDateTime departureDateTime = resultSet
                        .getTimestamp("date_time").toLocalDateTime();
                String categorie = resultSet.getString("categorie");
                int availableSeats = resultSet.getInt("available_seats");

                Spectacle spectacle = new Spectacle(Name1, departureDateTime, categorie, availableSeats);
                spectacle.setId(id);

                spectacles.add(spectacle);
            }
            logger.traceExit();
            return spectacles;
        } catch (SQLException e) {
            logger.error(e);
            e.printStackTrace();
        }
        logger.traceExit();
        return null;
    }
}
