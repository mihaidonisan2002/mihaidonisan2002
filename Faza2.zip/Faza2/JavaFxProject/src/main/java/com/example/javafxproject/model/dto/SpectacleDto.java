package com.example.javafxproject.model.dto;

import com.example.javafxproject.model.Spectacle;
import com.example.javafxproject.service.Service;

public class SpectacleDto {
    private Long id;
    private String name;
    private String dattime;
    private String categorie;
    private String avbSeats;

    public SpectacleDto(Spectacle spectacle, Service service) {
        this.id = spectacle.getId();
        this.name = spectacle.getName();
        this.dattime = spectacle.getDateTime().toString();
        this.categorie = spectacle.getCategorie();
        this.avbSeats = String.valueOf(spectacle.getAvailableSeats()-service.getNumberOfBookingsForSpectacle(spectacle.getId()));
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDattime() {
        return dattime;
    }

    public void setDattime(String datttime) {
        this.dattime = datttime;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public String getAvbSeats() {
        return avbSeats;
    }

    public void setAvbSeats(String avbSeats) {
        this.avbSeats = avbSeats;
    }
}
