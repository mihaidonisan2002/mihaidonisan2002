package com.example.javafxproject.repository;


import com.example.javafxproject.model.Spectacle;

import java.time.LocalDateTime;

public interface ISpectacleRepository extends CrudRepository<Long, Spectacle> {
    Iterable<Spectacle> findSpectacleByNameAndDate(String name, LocalDateTime dateTime);
}

