package com.example.javafxproject.model;

import java.util.List;

public class Booking extends Entity<Long> {

    private Spectacle spectacle;
    private Client client;
    private List<String> spectators;

    public Booking(Spectacle spectacle, Client client, List<String> spectators) {
        this.spectacle = spectacle;
        this.client = client;
        this.spectators = spectators;
    }

    public Spectacle getSpectacle() {
        return spectacle;
    }

    public void setSpectacle(Spectacle spectacle) {
        this.spectacle = spectacle;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public List<String> getSpectators() {
        return spectators;
    }

    public void setspectators(List<String> spectators) {
        this.spectators = spectators;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "spectacle=" + spectacle +
                ", client=" + client +
                ", spectators=" + spectators +
                '}';
    }
}
